/*
Test 1
Rental_Item_Fact:
compression: OLTP
PCTFREE: 10
nologging
Index: No
Partition: No

Product_Dim
compression: OLTP
pctfree: 10
nologging
index: no
partition: no

customer_dim
compression: oltp
pctfree: 10
nologging
index: no
partition: no

Test 2
Rental_Item_Fact:
compression: OLTP
parallel 32
PCTFREE: 0
nologging
Index: No
Partition: No

Product_Dim
compression: OLTP
parallel 4
pctfree: 0
nologging
index: no
partition: no

customer_dim
compression: oltp
parallel 32
pctfree: 0
nologging
index: no
partition: no
 
Test 3
Rental_Item_Fact:
compression: OLTP
PCTFREE: 0
nologging
Index: No
Partition: PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))

Product_Dim
compression: OLTP
pctfree: 0
nologging
index: no
partition: PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))

customer_dim
compression: oltp
pctfree: 0
nologging
index: no
partition: PARTITION BY RANGE ( customer_key ) INTERVAL ( 100000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))


Test 4
Rental_Item_Fact:
compression: OLTP
PCTFREE: 0
nologging
Index: create bitmap index rental_item_fact_4_bmix on rental_item_fact(date_key, product_key, customer_key)
Partition: PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))

Product_Dim
compression: OLTP
pctfree: 0
nologging
index: create index product_dim_4_ix on product_dim(product_key)
partition: PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))

customer_dim
compression: oltp
pctfree: 0
nologging
index: create index customer_dim_4_ix on customer_dim(customer_key)
partition: PARTITION BY RANGE ( customer_key ) INTERVAL ( 100000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))

Test 5
Rental_Item_Fact:
compression: OLTP
PCTFREE: 0
nologging
Index: bitmap join index
Partition: PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))

Product_Dim
compression: OLTP
pctfree: 0
nologging
index: bitmap join index
partition: PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))

customer_dim
compression: oltp
pctfree: 0
nologging
index: bitmap join index
partition: PARTITION BY RANGE ( customer_key ) INTERVAL ( 100000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))

*/
prompt date_dim pk
alter table date_dim_vs add constraint dd_pk primary key (date_key) parallel 32 nologging;

/*
prompt rif 2
--Test 2:
create table rental_item_fact_2
compress for oltp
nologging
pctfree 0
parallel 50
as
select * from rental_item_fact;

prompt pd 2
create table product_dim_2
compress for oltp
nologging
pctfree 0
parallel 50
as
select * from product_dim;

prompt pd 2 pk
alter table product_dim_2 add constraint pd_2_pk primary key (product_key) parallel 32 nologging;

prompt cd 2
create table customer_dim_2
compress for oltp
nologging
pctfree 0
parallel 50
as
select * from customer_dim;

prompt cd 2 pk
alter table customer_dim_2 add constraint cd_2_pk primary key (customer_key) parallel 32 nologging;


prompt rif 3
--Test 3:
create table rental_item_fact_3
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))
as 
select * from rental_item_fact;

prompt rif 3 ix
create index rif_3_ix on rental_item_fact_2(date_key, customer_key, product_key) parallel 32 nologging;

prompt pd 3
create table product_dim_3
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from product_dim;

prompt pd 3 pk
alter table product_dim_3 add constraint pd_3_pk primary key (product_key) parallel 32 nologging;

prompt cd 3
create table customer_dim_3
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( customer_key ) INTERVAL ( 500000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from customer_dim;

prompt cd 3 pk
alter table customer_dim_3 add constraint cd_3_pk primary key (customer_key) parallel 32 nologging;

prompt table 3 stats gather
begin
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'RENTAL_ITEM_FACT_3'
							,	degree => 50);
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'CUSTOMER_DIM_3'
							,	degree => 50);
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'PRODUCT_DIM_3'
							,	degree => 50);								
end;
/

prompt rif 4
--Test 4:
create table rental_item_fact_4
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))
as 
select * from rental_item_fact
order by date_key, product_key, customer_key;

prompt pd 4
create table product_dim_4
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from product_dim
order by product_key;

prompt cd 4
create table customer_dim_4
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( customer_key ) INTERVAL ( 500000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from customer_dim
order by customer_key;

prompt rif bmix date key
create bitmap index rif_dd_4_bmix on rental_item_fact_4(date_key) parallel 50 nologging local;
prompt rif bmix product key
create bitmap index rif_pd_4_bmix on rental_item_fact_4(product_key) parallel 50 nologging local;
prompt rif bmix customer key
create bitmap index rif_cd_4_bmix on rental_item_fact_4(customer_key) parallel 50 nologging local;
prompt cd 4 pk
alter table customer_dim_4 add constraint cd_4_pk primary key (customer_key) parallel 50 nologging;
prompt pd 4 pk
alter table product_dim_4 add constraint pd_4_pk primary key (product_key) parallel 50 nologging;


prompt tables 4 stats gather
begin
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'RENTAL_ITEM_FACT_4'
							,	degree => 50);
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'CUSTOMER_DIM_4'
							,	degree => 50);
DBMS_STATS.GATHER_TABLE_STATS (	ownname => 'VIDEO_STORE'
							,	tabname => 'PRODUCT_DIM_4'
							,	degree => 50);								
end;
/
*/
prompt rif 5
--Test 5:
create table rental_item_fact_5
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( date_key ) INTERVAL ( 100)  ( PARTITION p1 VALUES LESS THAN ( 20040500 ))
as 
select * from rental_item_fact
order by date_key, product_key, customer_key;

prompt pd 5
create table product_dim_5
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( product_key ) INTERVAL ( 50000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from product_dim
order by product_key;

prompt cd 5
create table customer_dim_5
compress for oltp
nologging
pctfree 0
parallel 50
PARTITION BY RANGE ( customer_key ) INTERVAL ( 500000)  ( PARTITION p1 VALUES LESS THAN ( 1 ))
as
select * from customer_dim
order by customer_key;

prompt pd 5 pk
alter table product_dim_5 add constraint pd_5_pk primary key (product_key) parallel 32 nologging;
prompt cd 5 pk
alter table customer_dim_5 add constraint cd_5_pk primary key (customer_key) parallel 32 nologging;

prompt rif bjix
CREATE BITMAP INDEX rif_cd_pd_5_bjix
ON rental_item_fact_5(product_dim_5.product_key, customer_dim_5.customer_key, date_dim_vs.date_key)
FROM rental_item_fact_5, product_dim_5, customer_dim_5, date_dim_vs
WHERE rental_item_fact_5.product_key = product_dim_5.product_key
AND rental_item_fact_5.customer_key = customer_dim_5.customer_key
and rental_item_fact_5.date_key = date_dim_vs.date_key
LOCAL parallel 32 NOLOGGING COMPUTE STATISTICS;
