CREATE TABLE street_suffix (
street_suffix_id	int
, street_suffix_full	varchar2(30)
, street_suffix_abbr	varchar2(30)
)
parallel 50
compress for oltp
nologging
;

INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Alley','ALY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Avenue','AVE');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Bend','BND');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Boulevard','BLVD');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Branch','BR');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Canyon','CYN');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Causeway','CSWY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Center','CTR');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Circle','CIR');
iNSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Corner','COR');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Court','CT');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Cove','CV');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Crossing','XING');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Divide','DV');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Drive','DR');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Estates','EST');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Expressway','EXPY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Field','FLD');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Fork','FORK');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Freeway','FWY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Gateway','GTWY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Highway','HWY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Hollow','HOLW');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Junction','JCT');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Landing','LNDG');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Lane','LN');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Park','PARK');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Parkway','PKY');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Pass','PASS');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Path','PATH');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Place','PL');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Point','PT');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Road','RD');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Row','ROW');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Springs','SPGS');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Spur','SPUR');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Square','SQ');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Street','ST');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Summit','SMT');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Terrace','TER');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Trace','TRCE');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Track','TRAK');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Trail','TRL');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Turnpike','TPKE');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Union','UN');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('View','VW');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Walk','WALK');
INSERT INTO street_suffix (street_suffix_full, street_suffix_abbr) VALUES ('Way','WAY');

COMMIT;

MERGE INTO street_suffix A 
using (SELECT ROWNUM row_num, street_suffix_full, street_suffix_abbr
FROM street_suffix) b
ON (A.street_suffix_full = b.street_suffix_full
		AND A.street_suffix_abbr = b.street_suffix_abbr)
WHEN MATCHED THEN 
UPDATE set A.STREET_SUFFIX_ID = b.row_num;

commit;
