@video_store_dw.sql
@table_test_create.sql
@test_runs.sql