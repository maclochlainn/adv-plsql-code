prompt Test 10 || 1 : All
prompt Test 10 || 1 : 1
exec stat_snap.start_snap('10 || 1 : All');
exec stat_snap.start_snap('10 || 1 : 1');

-- Count of Rental Item Fact
select count(*) from video_store.rental_item_fact;

exec stat_snap.end_snap('10 || 1 : 1');
prompt Test 10 || 1 : 2
exec stat_snap.start_snap('10 || 1 : 2');

-- Predicate Offload
-- Sales by genre by state for December 2012

SELECT 
  product_genre
, ADDRESS_REGION
, sum(sale_net)
FROM
	video_store.rental_item_fact rif
JOIN
	video_store.product_dim pd
  	ON rif.product_key = pd.product_key
JOIN
	video_store.customer_dim cd
		ON cd.customer_Key = rif.customer_Key
JOIN
	video_store.date_dim_vs dd
		ON rif.date_key = dd.date_key
WHERE 
	date_curr BETWEEN to_date('20121201', 'yyyymmdd') AND to_date('20121231', 'yyyymmdd')
GROUP BY ADDRESS_REGION, product_genre;

exec stat_snap.end_snap('10 || 1 : 2');
prompt Test 10 || 1 : 3
exec stat_snap.start_snap('10 || 1 : 3');


-- Full Table Scan
-- Sales by region by year
WITH alpha AS (
SELECT 
	cd.address_region
, dd.date_year
, sum(rif.sale_net) sale_net
FROM
	video_store.rental_item_fact rif
JOIN
	video_store.customer_dim cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.date_dim_vs dd
  	ON rif.date_key = dd.date_key
GROUP BY 
	cd.address_region
, dd.date_year)
SELECT * FROM alpha
pivot
	(max(sale_net)
  FOR (date_year)
  IN(2005, 2006, 2007,2008,2009,2010,2011,2012, 2013, 2014)
  )
  ORDER BY address_region;
  
  
  
exec stat_snap.end_snap('10 || 1 : 3'); 
prompt Test 10 || 1 : 4
exec stat_snap.start_snap('10 || 1 : 4');  


-- Predicate Offload
-- Sales by Product for Single State  
  
  SELECT 
	pd.product_genre
,	sum(rif.sale_net) sales_net
FROM
	video_store.rental_item_fact rif
JOIN
	video_store.customer_dim cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.product_dim pd
  	ON pd.product_key = rif.product_key
    WHERE cd.address_region = 'ID'
    GROUP BY pd.product_genre;

	
	
exec stat_snap.end_snap('10 || 1 : 4');	
prompt Test 10 || 1 : 5
exec stat_snap.start_snap('10 || 1 : 5');

-- Predicate Offload	
-- Sale history for single customer
	
    	SELECT 
	cd.name_full
, pd.product_title
, pd.product_genre
, to_date(rif.date_key, 'yyyymmdd') purchase_date
, rif.sale_price
FROM
	video_store.rental_item_fact rif
INNER JOIN
	video_store.customer_dim cd
 		ON rif.customer_key = cd.customer_key
INNER JOIN
	video_store.product_dim pd
  	ON rif.product_key = pd.product_key
WHERE cd.name_full = 'Abraham Jimmie Hubbard'
ORDER BY rif.date_key;



exec stat_snap.end_snap('10 || 1 : 5');
prompt Test 10 || 1 : 6
exec stat_snap.start_snap('10 || 1 : 6');	
-- Kasey's Query
	
	
SELECT 
  pd.product_rating
,  cd.demographic_gender
,  dd.date_month_of_year
,  sum ( rif.product_price )  product_price_daily_total
,  sum ( rif.product_cost  )  product_cost_daily_total
,  sum ( rif.sale_price    )  sale_price_daily_total
,  sum ( rif.sale_cost     )  sale_cost_daily_total
,  sum ( rif.sale_net      )  sale_net_daily_total
FROM  
	video_store.rental_item_fact rif
INNER JOIN 
	video_store.product_dim  pd 
  	ON rif.product_key = pd.product_key
INNER JOIN 
	video_store.customer_dim cd 
  	ON rif.customer_key = cd.customer_key
INNER JOIN 
	date_dim_vs     dd 
		ON rif.date_key = dd.date_key
  WHERE  cd.demographic_gender = 'M'     
  AND  dd.date_curr BETWEEN '01-Jan-2013' AND '31-Jan-2013'
  AND rif.date_key BETWEEN 20130101 AND 20130131
  AND  product_rating IN ( 'PG', 'PG-13')
GROUP BY  pd.product_rating
     		, cd.demographic_gender
     		, dd.date_month_of_year
ORDER BY  pd.product_rating
       ,  dd.date_month_of_year;
	   
	   
exec stat_snap.end_snap('10 || 1 : 6');
exec stat_snap.end_snap('10 || 1 : All');
-- Test 2

prompt Test 10 || 2 : All
prompt Test 10 || 2 : 1
exec stat_snap.start_snap('10 || 2 : All');
exec stat_snap.start_snap('10 || 2 : 1');

-- Count of Rental Item Fact
select count(*) from video_store.rental_item_fact_2;

exec stat_snap.end_snap('10 || 2 : 1');
prompt Test 10 || 2 : 2
exec stat_snap.start_snap('10 || 2 : 2');

-- Predicate Offload
-- Sales by genre by state for December 2012

SELECT 
  product_genre
, ADDRESS_REGION
, sum(sale_net)
FROM
	video_store.rental_item_fact_2 rif
JOIN
	video_store.product_dim_2 pd
  	ON rif.product_key = pd.product_key
JOIN
	video_store.customer_dim_2 cd
		ON cd.customer_Key = rif.customer_Key
JOIN
	video_store.date_dim_vs dd
		ON rif.date_key = dd.date_key
WHERE 
	date_curr BETWEEN to_date('20121201', 'yyyymmdd') AND to_date('20121231', 'yyyymmdd')
GROUP BY ADDRESS_REGION, product_genre;

exec stat_snap.end_snap('10 || 2 : 2');
prompt Test 10 || 2 : 3
exec stat_snap.start_snap('10 || 2 : 3');


-- Full Table Scan
-- Sales by region by year
WITH alpha AS (
SELECT 
	cd.address_region
, dd.date_year
, sum(rif.sale_net) sale_net
FROM
	video_store.rental_item_fact_2 rif
JOIN
	video_store.customer_dim_2 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.date_dim_vs dd
  	ON rif.date_key = dd.date_key
GROUP BY 
	cd.address_region
, dd.date_year)
SELECT * FROM alpha
pivot
	(max(sale_net)
  FOR (date_year)
  IN(2005, 2006, 2007,2008,2009,2010,2011,2012, 2013, 2014)
  )
  ORDER BY address_region;
  
  
  
exec stat_snap.end_snap('10 || 2 : 3'); 
prompt Test 10 || 2 : 4
exec stat_snap.start_snap('10 || 2 : 4');  


-- Predicate Offload
-- Sales by Product for Single State  
  
  SELECT 
	pd.product_genre
,	sum(rif.sale_net) sales_net
FROM
	video_store.rental_item_fact_2 rif
JOIN
	video_store.customer_dim_2 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.product_dim_2 pd
  	ON pd.product_key = rif.product_key
    WHERE cd.address_region = 'ID'
    GROUP BY pd.product_genre;

	
	
exec stat_snap.end_snap('10 || 2 : 4');	
prompt Test 10 || 2 : 5
exec stat_snap.start_snap('10 || 2 : 5');

-- Predicate Offload	
-- Sale history for single customer
	
    	SELECT 
	cd.name_full
, pd.product_title
, pd.product_genre
, to_date(rif.date_key, 'yyyymmdd') purchase_date
, rif.sale_price
FROM
	video_store.rental_item_fact_2 rif
INNER JOIN
	video_store.customer_dim_2 cd
 		ON rif.customer_key = cd.customer_key
INNER JOIN
	video_store.product_dim_2 pd
  	ON rif.product_key = pd.product_key
WHERE cd.name_full = 'Abraham Jimmie Hubbard'
ORDER BY rif.date_key;



exec stat_snap.end_snap('10 || 2 : 5');
prompt Test 10 || 2 : 6
exec stat_snap.start_snap('10 || 2 : 6');	
-- Kasey's Query
	
	
SELECT 
  pd.product_rating
,  cd.demographic_gender
,  dd.date_month_of_year
,  sum ( rif.product_price )  product_price_daily_total
,  sum ( rif.product_cost  )  product_cost_daily_total
,  sum ( rif.sale_price    )  sale_price_daily_total
,  sum ( rif.sale_cost     )  sale_cost_daily_total
,  sum ( rif.sale_net      )  sale_net_daily_total
FROM  
	video_store.rental_item_fact_2 rif
INNER JOIN 
	video_store.product_dim_2  pd 
  	ON rif.product_key = pd.product_key
INNER JOIN 
	video_store.customer_dim_2 cd 
  	ON rif.customer_key = cd.customer_key
INNER JOIN 
	date_dim_vs     dd 
		ON rif.date_key = dd.date_key
  WHERE  cd.demographic_gender = 'M'     
  AND  dd.date_curr BETWEEN '01-Jan-2013' AND '31-Jan-2013'
  AND rif.date_key BETWEEN 20130101 AND 20130131
  AND  product_rating IN ( 'PG', 'PG-13')
GROUP BY  pd.product_rating
     		, cd.demographic_gender
     		, dd.date_month_of_year
ORDER BY  pd.product_rating
       ,  dd.date_month_of_year;
	   
	   
exec stat_snap.end_snap('10 || 2 : 6');
exec stat_snap.end_snap('10 || 2 : All');
-- Test 2

prompt Test 10 || 3 : All
prompt Test 10 || 3 : 1
exec stat_snap.start_snap('10 || 3 : All');
exec stat_snap.start_snap('10 || 3 : 1');

-- Count of Rental Item Fact
select count(*) from video_store.rental_item_fact_3;

exec stat_snap.end_snap('10 || 3 : 1');
prompt Test 10 || 3 : 2
exec stat_snap.start_snap('10 || 3 : 2');

-- Predicate Offload
-- Sales by genre by state for December 2012

SELECT 
  product_genre
, ADDRESS_REGION
, sum(sale_net)
FROM
	video_store.rental_item_fact_3 rif
JOIN
	video_store.product_dim_3 pd
  	ON rif.product_key = pd.product_key
JOIN
	video_store.customer_dim_3 cd
		ON cd.customer_Key = rif.customer_Key
JOIN
	video_store.date_dim_vs dd
		ON rif.date_key = dd.date_key
WHERE 
	date_curr BETWEEN to_date('20121201', 'yyyymmdd') AND to_date('20121231', 'yyyymmdd')
GROUP BY ADDRESS_REGION, product_genre;

exec stat_snap.end_snap('10 || 3 : 2');
prompt Test 10 || 3 : 3
exec stat_snap.start_snap('10 || 3 : 3');


-- Full Table Scan
-- Sales by region by year
WITH alpha AS (
SELECT 
	cd.address_region
, dd.date_year
, sum(rif.sale_net) sale_net
FROM
	video_store.rental_item_fact_3 rif
JOIN
	video_store.customer_dim_3 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.date_dim_vs dd
  	ON rif.date_key = dd.date_key
GROUP BY 
	cd.address_region
, dd.date_year)
SELECT * FROM alpha
pivot
	(max(sale_net)
  FOR (date_year)
  IN(2005, 2006, 2007,2008,2009,2010,2011,2012, 2013, 2014)
  )
  ORDER BY address_region;
  
  
  
exec stat_snap.end_snap('10 || 3 : 3'); 
prompt Test 10 || 3 : 4
exec stat_snap.start_snap('10 || 3 : 4');  


-- Predicate Offload
-- Sales by Product for Single State  
  
  SELECT 
	pd.product_genre
,	sum(rif.sale_net) sales_net
FROM
	video_store.rental_item_fact_3 rif
JOIN
	video_store.customer_dim_3 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.product_dim_3 pd
  	ON pd.product_key = rif.product_key
    WHERE cd.address_region = 'ID'
    GROUP BY pd.product_genre;

	
	
exec stat_snap.end_snap('10 || 3 : 4');	
prompt Test 10 || 3 : 5
exec stat_snap.start_snap('10 || 3 : 5');

-- Predicate Offload	
-- Sale history for single customer
	
    	SELECT 
	cd.name_full
, pd.product_title
, pd.product_genre
, to_date(rif.date_key, 'yyyymmdd') purchase_date
, rif.sale_price
FROM
	video_store.rental_item_fact_3 rif
INNER JOIN
	video_store.customer_dim_3 cd
 		ON rif.customer_key = cd.customer_key
INNER JOIN
	video_store.product_dim_3 pd
  	ON rif.product_key = pd.product_key
WHERE cd.name_full = 'Abraham Jimmie Hubbard'
ORDER BY rif.date_key;



exec stat_snap.end_snap('10 || 3 : 5');
prompt Test 10 || 3 : 6
exec stat_snap.start_snap('10 || 3 : 6');	
-- Kasey's Query
	
	
SELECT 
  pd.product_rating
,  cd.demographic_gender
,  dd.date_month_of_year
,  sum ( rif.product_price )  product_price_daily_total
,  sum ( rif.product_cost  )  product_cost_daily_total
,  sum ( rif.sale_price    )  sale_price_daily_total
,  sum ( rif.sale_cost     )  sale_cost_daily_total
,  sum ( rif.sale_net      )  sale_net_daily_total
FROM  
	video_store.rental_item_fact_3 rif
INNER JOIN 
	video_store.product_dim_3  pd 
  	ON rif.product_key = pd.product_key
INNER JOIN 
	video_store.customer_dim_3 cd 
  	ON rif.customer_key = cd.customer_key
INNER JOIN 
	date_dim_vs     dd 
		ON rif.date_key = dd.date_key
  WHERE  cd.demographic_gender = 'M'     
  AND  dd.date_curr BETWEEN '01-Jan-2013' AND '31-Jan-2013'
  AND rif.date_key BETWEEN 20130101 AND 20130131
  AND  product_rating IN ( 'PG', 'PG-13')
GROUP BY  pd.product_rating
     		, cd.demographic_gender
     		, dd.date_month_of_year
ORDER BY  pd.product_rating
       ,  dd.date_month_of_year;
	   
	   
exec stat_snap.end_snap('10 || 3 : 6');
exec stat_snap.end_snap('10 || 3 : All');
-- Test 2

prompt Test 10 || 4 : All
prompt Test 10 || 4 : 1
exec stat_snap.start_snap('10 || 4 : All');
exec stat_snap.start_snap('10 || 4 : 1');

-- Count of Rental Item Fact
select count(*) from video_store.rental_item_fact_4;

exec stat_snap.end_snap('10 || 4 : 1');
prompt Test 10 || 4 : 2
exec stat_snap.start_snap('10 || 4 : 2');

-- Predicate Offload
-- Sales by genre by state for December 2012

SELECT 
  product_genre
, ADDRESS_REGION
, sum(sale_net)
FROM
	video_store.rental_item_fact_4 rif
JOIN
	video_store.product_dim_4 pd
  	ON rif.product_key = pd.product_key
JOIN
	video_store.customer_dim_4 cd
		ON cd.customer_Key = rif.customer_Key
JOIN
	video_store.date_dim_vs dd
		ON rif.date_key = dd.date_key
WHERE 
	date_curr BETWEEN to_date('20121201', 'yyyymmdd') AND to_date('20121231', 'yyyymmdd')
GROUP BY ADDRESS_REGION, product_genre;

exec stat_snap.end_snap('10 || 4 : 2');
prompt Test 10 || 4 : 3
exec stat_snap.start_snap('10 || 4 : 3');


-- Full Table Scan
-- Sales by region by year
WITH alpha AS (
SELECT 
	cd.address_region
, dd.date_year
, sum(rif.sale_net) sale_net
FROM
	video_store.rental_item_fact_4 rif
JOIN
	video_store.customer_dim_4 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.date_dim_vs dd
  	ON rif.date_key = dd.date_key
GROUP BY 
	cd.address_region
, dd.date_year)
SELECT * FROM alpha
pivot
	(max(sale_net)
  FOR (date_year)
  IN(2005, 2006, 2007,2008,2009,2010,2011,2012, 2013, 2014)
  )
  ORDER BY address_region;
  
  
  
exec stat_snap.end_snap('10 || 4 : 3'); 
prompt Test 10 || 4 : 4
exec stat_snap.start_snap('10 || 4 : 4');  


-- Predicate Offload
-- Sales by Product for Single State  
  
  SELECT 
	pd.product_genre
,	sum(rif.sale_net) sales_net
FROM
	video_store.rental_item_fact_4 rif
JOIN
	video_store.customer_dim_4 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.product_dim_4 pd
  	ON pd.product_key = rif.product_key
    WHERE cd.address_region = 'ID'
    GROUP BY pd.product_genre;

	
	
exec stat_snap.end_snap('10 || 4 : 4');	
prompt Test 10 || 4 : 5
exec stat_snap.start_snap('10 || 4 : 5');

-- Predicate Offload	
-- Sale history for single customer
	
    	SELECT 
	cd.name_full
, pd.product_title
, pd.product_genre
, to_date(rif.date_key, 'yyyymmdd') purchase_date
, rif.sale_price
FROM
	video_store.rental_item_fact_4 rif
INNER JOIN
	video_store.customer_dim_4 cd
 		ON rif.customer_key = cd.customer_key
INNER JOIN
	video_store.product_dim_4 pd
  	ON rif.product_key = pd.product_key
WHERE cd.name_full = 'Abraham Jimmie Hubbard'
ORDER BY rif.date_key;



exec stat_snap.end_snap('10 || 4 : 5');
prompt Test 10 || 4 : 6
exec stat_snap.start_snap('10 || 4 : 6');	
-- Kasey's Query
	
	
SELECT 
  pd.product_rating
,  cd.demographic_gender
,  dd.date_month_of_year
,  sum ( rif.product_price )  product_price_daily_total
,  sum ( rif.product_cost  )  product_cost_daily_total
,  sum ( rif.sale_price    )  sale_price_daily_total
,  sum ( rif.sale_cost     )  sale_cost_daily_total
,  sum ( rif.sale_net      )  sale_net_daily_total
FROM  
	video_store.rental_item_fact_4 rif
INNER JOIN 
	video_store.product_dim_4  pd 
  	ON rif.product_key = pd.product_key
INNER JOIN 
	video_store.customer_dim_4 cd 
  	ON rif.customer_key = cd.customer_key
INNER JOIN 
	date_dim_vs     dd 
		ON rif.date_key = dd.date_key
  WHERE  cd.demographic_gender = 'M'     
  AND  dd.date_curr BETWEEN '01-Jan-2013' AND '31-Jan-2013'
  AND rif.date_key BETWEEN 20130101 AND 20130131
  AND  product_rating IN ( 'PG', 'PG-13')
GROUP BY  pd.product_rating
     		, cd.demographic_gender
     		, dd.date_month_of_year
ORDER BY  pd.product_rating
       ,  dd.date_month_of_year;
	   
	   
exec stat_snap.end_snap('10 || 4 : 6');
exec stat_snap.end_snap('10 || 4 : All');
-- Test 2

prompt Test 10 || 5 : All
prompt Test 10 || 5 : 1
exec stat_snap.start_snap('10 || 5 : All');
exec stat_snap.start_snap('10 || 5 : 1');

-- Count of Rental Item Fact
select count(*) from video_store.rental_item_fact_5;

exec stat_snap.end_snap('10 || 5 : 1');
prompt Test 10 || 5 : 2
exec stat_snap.start_snap('10 || 5 : 2');

-- Predicate Offload
-- Sales by genre by state for December 2012

SELECT 
  product_genre
, ADDRESS_REGION
, sum(sale_net)
FROM
	video_store.rental_item_fact_5 rif
JOIN
	video_store.product_dim_5 pd
  	ON rif.product_key = pd.product_key
JOIN
	video_store.customer_dim_5 cd
		ON cd.customer_Key = rif.customer_Key
JOIN
	video_store.date_dim_vs dd
		ON rif.date_key = dd.date_key
WHERE 
	date_curr BETWEEN to_date('20121201', 'yyyymmdd') AND to_date('20121231', 'yyyymmdd')
GROUP BY ADDRESS_REGION, product_genre;

exec stat_snap.end_snap('10 || 5 : 2');
prompt Test 10 || 5 : 3
exec stat_snap.start_snap('10 || 5 : 3');


-- Full Table Scan
-- Sales by region by year
WITH alpha AS (
SELECT 
	cd.address_region
, dd.date_year
, sum(rif.sale_net) sale_net
FROM
	video_store.rental_item_fact_5 rif
JOIN
	video_store.customer_dim_5 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.date_dim_vs dd
  	ON rif.date_key = dd.date_key
GROUP BY 
	cd.address_region
, dd.date_year)
SELECT * FROM alpha
pivot
	(max(sale_net)
  FOR (date_year)
  IN(2005, 2006, 2007,2008,2009,2010,2011,2012, 2013, 2014)
  )
  ORDER BY address_region;
  
  
  
exec stat_snap.end_snap('10 || 5 : 3'); 
prompt Test 10 || 5 : 4
exec stat_snap.start_snap('10 || 5 : 4');  


-- Predicate Offload
-- Sales by Product for Single State  
  
  SELECT 
	pd.product_genre
,	sum(rif.sale_net) sales_net
FROM
	video_store.rental_item_fact_5 rif
JOIN
	video_store.customer_dim_5 cd
  	ON rif.customer_Key = cd.customer_key
JOIN
	video_store.product_dim_5 pd
  	ON pd.product_key = rif.product_key
    WHERE cd.address_region = 'ID'
    GROUP BY pd.product_genre;

	
	
exec stat_snap.end_snap('10 || 5 : 4');	
prompt Test 10 || 5 : 5
exec stat_snap.start_snap('10 || 5 : 5');

-- Predicate Offload	
-- Sale history for single customer
	
    	SELECT 
	cd.name_full
, pd.product_title
, pd.product_genre
, to_date(rif.date_key, 'yyyymmdd') purchase_date
, rif.sale_price
FROM
	video_store.rental_item_fact_5 rif
INNER JOIN
	video_store.customer_dim_5 cd
 		ON rif.customer_key = cd.customer_key
INNER JOIN
	video_store.product_dim_5 pd
  	ON rif.product_key = pd.product_key
WHERE cd.name_full = 'Abraham Jimmie Hubbard'
ORDER BY rif.date_key;



exec stat_snap.end_snap('10 || 5 : 5');
prompt Test 10 || 5 : 6
exec stat_snap.start_snap('10 || 5 : 6');	
-- Kasey's Query
	
	
SELECT 
  pd.product_rating
,  cd.demographic_gender
,  dd.date_month_of_year
,  sum ( rif.product_price )  product_price_daily_total
,  sum ( rif.product_cost  )  product_cost_daily_total
,  sum ( rif.sale_price    )  sale_price_daily_total
,  sum ( rif.sale_cost     )  sale_cost_daily_total
,  sum ( rif.sale_net      )  sale_net_daily_total
FROM  
	video_store.rental_item_fact_5 rif
INNER JOIN 
	video_store.product_dim_5  pd 
  	ON rif.product_key = pd.product_key
INNER JOIN 
	video_store.customer_dim_5 cd 
  	ON rif.customer_key = cd.customer_key
INNER JOIN 
	date_dim_vs     dd 
		ON rif.date_key = dd.date_key
  WHERE  cd.demographic_gender = 'M'     
  AND  dd.date_curr BETWEEN '01-Jan-2013' AND '31-Jan-2013'
  AND rif.date_key BETWEEN 20130101 AND 20130131
  AND  product_rating IN ( 'PG', 'PG-13')
GROUP BY  pd.product_rating
     		, cd.demographic_gender
     		, dd.date_month_of_year
ORDER BY  pd.product_rating
       ,  dd.date_month_of_year;
	   
	   
exec stat_snap.end_snap('10 || 5 : 6');
exec stat_snap.end_snap('10 || 5 : All');
exec stat_snap.table_snap();
