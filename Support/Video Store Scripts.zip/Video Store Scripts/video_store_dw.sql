ME:   video_store_dw.sql
AUTHOR(S):  John M Harper, Michael McLaughlin, Brandon Hawkes, Tyler Hawkes
COPYRIGHT:  (c) 2014 McLaughlin Software Development LLC.
                McGraw-Hill use is granted for educational purposes. Commercial
                use is granted by written consent. Please remit requests to:
                  + john.maurice.harper@mclaughlinsoftware.com
                  + michael.mclaughlin@mclaughlinsoftware.com
                  + tyler.hawkes@mclaughlinsoftware.com
                  + brandon.hawkes@mclaughlinsoftware.com
--------------------------------------------------------------------------------
CHANGE_RECORD
================================================================================
DATE        INITIALS    REASON
--------------------------------------------------------------------------------
14-MAY-2014 JMH         A unified method of creating the dimensional tables for
                        our book examples.
*****************************************************************************  */
set serveroutput on;
set tab off;
set timing on;
--------------------------------------------------------------------------------
-- DROP video_store tables
--------------------------------------------------------------------------------
/*
PROMPT Dropping VIDEO_STORE tables.
DECLARE
  CURSOR c IS
    SELECT  table_name
      FROM  user_tables
     WHERE  table_name IN
            (
              'DATE_DIM_VS'
            , 'CUSTOMER_DIM'
            , 'ZIP_CITY'
            , 'LIST_FEMALE_NAME'
            , 'LIST_MALE_NAME'
			, 'LIST_LAST_NAME'
			, 'ITERATOR_5M'
            , 'PRODUCT_DIM'
            , 'STREET_NAME'
            , 'STREET_SUFFIX'
            , 'ITERATOR'
            , 'RENTAL_ITEM_FACT'
            );
BEGIN
  FOR r IN c LOOP
    execute immediate ' drop table video_store.'||r.table_name||' cascade constraints purge ';
  END LOOP;
END;
/

--------------------------------------------------------------------------------
-- create list tables
--------------------------------------------------------------------------------
PROMPT Creating zip_city
start cities.sql;
PROMPT Creating list_female_name
start list_female_name.sql;
PROMPT Creating list_male_name
start list_male_name.sql;
PROMPT Creating list_last_name
start list_last_name.sql
PROMPT Creating street_name
start street_name.sql;
PROMPT Creating street_suffix
start street_suffix.sql
--------------------------------------------------------------------------------
-- create date_dim
--------------------------------------------------------------------------------
-- PROMPT Creating VIDEO_STORE.DATE_DIM.
CREATE TABLE video_store.date_dim_vs
 PARALLEL 50
 COMPRESS FOR oltp
 NOLOGGING
 PARTITION BY RANGE ( date_curr ) INTERVAL(NUMTOYMINTERVAL(1, 'YEAR')) -- something wrong here...
   ( PARTITION p1 VALUES LESS THAN ( '01-AUG-1776' ))
 AS
 WITH
 i AS
 (
     SELECT  LEVEL date_iterator
          ,  TRUNC ( sysdate ) now
       FROM  dual
 CONNECT BY  LEVEL <= ( to_date('31-Dec-2040') - TO_DATE ( '4-Jul-1776' ))
   ORDER BY  LEVEL desc
 )
   SELECT  ROWNUM                                    AS date_id
        ,  TO_NUMBER ( TO_CHAR ( to_date('31-Dec-2040') - date_iterator, 'YYYYMMDD' ))  AS date_key
        ,  trunc(to_date('31-Dec-2040')) - date_iterator                                       AS date_curr
        ,  trunc(to_date('31-Dec-2040')) - date_iterator - 1                                   AS date_prev
        ,  trunc(to_date('31-Dec-2040')) - date_iterator + 1                                   AS date_next
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'DS'    )                  AS date_short
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'fmMonth DD, YYYY'     )   AS date_name
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'fmMonth Ddth, YYYY'   )   AS date_name_long_th
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'fmMonth Ddspth, YYYY' )   AS date_name_long_sp
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'Day'   )                  AS date_day_name
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'DY'    )                  AS date_day_name_short
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'D'     ))                  AS date_day_of_week
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'DD'    ))                  AS date_day_of_month
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'DDD'   ))                  AS date_day_of_year
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'W'     ))                  AS date_week_of_month
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'WW'    ))                  AS date_week_of_year
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'MONTH' )                  AS date_month_name
        ,  TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'MON'   )                  AS date_month_name_short
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'MM'    ))                  AS date_month_of_year
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'Q'     ))                  AS date_quarter_of_year
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'SYYYY' ))                  AS date_year
        ,  TO_NUMBER(TO_CHAR ( trunc(to_date('31-Dec-2040')) - date_iterator, 'YY'    ))                  AS date_year_short
     FROM  i;
--------------------------------------------------------------------------------
-- create customer_dim (run against both nodes)
--------------------------------------------------------------------------------
PROMPT Creating VIDEO_STORE.CUSTOMER_DIM.
CREATE TABLE video_store.iterator_5M parallel 50  compress for oltp nologging AS SELECT LEVEL i FROM DUAL CONNECT BY LEVEL <= 5000000;
CREATE TABLE video_store.customer_dim
parallel 50
compress for oltp
nologging
AS
WITH
random_iterator AS
(
    SELECT  ROUND ( DBMS_RANDOM.VALUE ( 1, 38853 )) zip_city_id      -- gets postcode, city name, state and area code
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,  2458 )) street_name_id   -- gets street name
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,    49 )) street_suffix_id -- gets street suffix 49 is null
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,   999 )) given_name_id_1
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,   999 )) given_name_id_2
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,   999 )) family_name_id
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,     5 )) extra_gn
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,     5 )) gender_type
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,     5 )) cc_type
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,     5 )) dg_type
         ,  ROUND ( DBMS_RANDOM.VALUE ( 1,  1825 )) created
      FROM  video_store.iterator_5M
),
base_set AS
(
SELECT  'United States' address_country
     ,  ROUND ( DBMS_RANDOM.VALUE ( 1, 8000 )) ||
        ' ' ||
        sn.street_name ||
        ' ' ||
        CASE
          WHEN ss.street_suffix_id > 30
          THEN NULL
          ELSE ss.street_suffix_full
        END address_line_primary
     ,  CASE
          WHEN ss.street_suffix_id between 40 and 49
          THEN 'APT#' || ROUND ( DBMS_RANDOM.VALUE ( 1, 900 ))
        END address_line_secondary
     ,  zc.city_name || ' ' || zc.state || ', ' || zc.zip address_line_tertiary
     ,  zc.zip address_postcode
     ,  zc.state address_region
     ,  ROUND ( DBMS_RANDOM.VALUE ( 1111111111111111, 99999999999999999 )) credit_card -- i will make this better later
     ,  CASE
          WHEN CC_TYPE = 1 THEN 'VISA'
          WHEN CC_TYPE = 2 THEN 'MASTERCARD'
          WHEN CC_TYPE = 3 THEN 'DISCOVER'
          WHEN CC_TYPE = 4 THEN 'AMEX'
          WHEN CC_TYPE = 5 THEN 'DINERS CLUB'
        END credit_card_type
     ,  CASE
          WHEN cc_type BETWEEN 1 AND 2 THEN 180
          WHEN cc_type BETWEEN 2 AND 3 THEN  90
          ELSE 30
        END credit_term
     ,  SYSDATE - DBMS_RANDOM.VALUE ( 6575, 32850 ) demographic_birthdate
     ,  ROUND ( DBMS_RANDOM.VALUE ( 15000, 3000000 )) demographic_income
     ,  CASE
          WHEN gender_type < 3 THEN 'F'
          ELSE 'M'
        END demographic_gender
     ,  CASE
          WHEN gender_type <  3 AND extra_gn <  4 THEN lfn1.name
          WHEN gender_type <  3 AND extra_gn >= 4 THEN lfn1.name || ' ' || lfn2.name
          WHEN gender_type >= 3 AND extra_gn <  2 THEN lmn1.name
          WHEN gender_type >= 3 AND extra_gn >= 2 THEN lmn1.name || ' ' || lmn2.name
        END name_given
     ,  lln.name name_family
     ,  case
          WHEN dg_type BETWEEN 1 AND 2 THEN 'Caucasian'
          WHEN dg_type BETWEEN 2 AND 3 THEN 'African American'
          WHEN dg_type BETWEEN 3 AND 4 THEN 'Hispanic'
          WHEN dg_type BETWEEN 4 AND 5 THEN 'Asian'
        END demographic_race
     ,  '+1 (' || ZC.AREACODE || ') '||
        ROUND ( DBMS_RANDOM.VALUE ( 111,999 )) || '-' ||
        ROUND ( DBMS_RANDOM.VALUE ( 1111, 9999 )) PHONE_CELL
     ,  '+1 (' || zc.areacode || ') '||
        ROUND ( DBMS_RANDOM.VALUE ( 111,999 )) || '-' ||
        ROUND ( DBMS_RANDOM.VALUE ( 1111, 9999 )) PHONE_FAX
     ,  '+1 (' || zc.areacode || ') '||
        ROUND ( DBMS_RANDOM.VALUE ( 111,999 )) || '-' ||
        ROUND ( DBMS_RANDOM.VALUE ( 1111, 9999 )) PHONE_HOME
     ,  '+1 (' || zc.areacode || ') '||
        ROUND ( DBMS_RANDOM.VALUE ( 111,999 )) || '-' ||
        ROUND ( DBMS_RANDOM.VALUE ( 1111, 9999 )) phone_pager
     ,  SYSDATE - created dt_created
     ,  SYSDATE - created dt_effective_start
     ,  CAST ( NULL AS DATE ) dt_effective_end
  FROM  random_iterator ri
          LEFT JOIN video_store.zip_city zc ON ri.zip_city_id = zc.zip_city_id
          LEFT JOIN video_store.street_name sn ON ri.street_name_id = sn.street_name_id
          LEFT JOIN video_store.street_suffix ss ON ri.street_suffix_id = ss.street_suffix_id
          LEFT JOIN video_store.list_female_name lfn1 ON ri.given_name_id_1 = lfn1.list_id
          LEFT JOIN video_store.list_female_name lfn2 ON ri.given_name_id_2 = lfn2.list_id
          LEFT JOIN video_store.list_male_name lmn1 ON ri.given_name_id_1 = lmn1.list_id
          LEFT JOIN video_store.list_male_name lmn2 ON ri.given_name_id_2 = lmn2.list_id
          LEFT JOIN video_store.list_last_name lln ON ri.family_name_id = lln.list_id
)
SELECT  rownum customer_key
     ,  address_country
     ,  address_line_primary ||
        decode ( address_line_secondary, null, null, address_line_secondary || ' ' ) ||
        address_line_tertiary full_address
     ,  address_line_primary
     ,  address_line_secondary
     ,  address_line_tertiary
     ,  address_postcode
     ,  address_region
     ,  credit_card
     ,  credit_card_type
     ,  credit_term
     ,  demographic_birthdate
     ,  demographic_gender
     ,  demographic_income
     ,  demographic_race
     ,  name_family || '.' ||
        regexp_replace ( name_given, '[[:space:]]*','' ) ||
        '@fabricated-email.com' email
     ,  CAST ( null AS VARCHAR2(50)) name_adopted
     ,  name_family
     ,  name_given || ' ' || name_family name_full
     ,  name_given
     ,  phone_cell
     ,  phone_fax
     ,  phone_home
     ,  phone_pager
     ,  dt_created
     ,  dt_effective_start
     ,  dt_effective_end
     ,  sysdate dt_update
  FROM  base_set
;
--------------------------------------------------------------------------------
-- create product_dim
--------------------------------------------------------------------------------
PROMPT Creating product_dim
start product_dim.sql;
--------------------------------------------------------------------------------
-- create rental_item_fact (run against both nodes)
--------------------------------------------------------------------------------

-- create table video_store.iterator parallel 50 nologging compress for oltp  as select 1 i from dual connect by level <= 5859375;
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit;
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit;
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit; 
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit;
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit; 
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit; 
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit; 
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator;
-- commit; 
-- insert /*+ append parallel 50*/ into video_store.iterator select * from video_store.iterator; 
-- commit;  
*/
create table iterator_50M  nologging parallel 50  as
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M
union all
select * from iterator_5M;

create table iterator_500m nologging parallel 50 as
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M
union all
select * from iterator_50M;

commit;

create table iterator
nologging parallel 50
as 
select * from iterator_500M
union all
select * from iterator_500M
union all
select * from iterator_500M
union all
select * from iterator_500M
union all
select * from iterator_500M
union all
select * from iterator_500M;

commit;



CREATE TABLE video_store.rental_item_fact
PARALLEL 50
compress for oltp
nologging
AS
WITH
base_values AS
(
  SELECT  ROUND ( DBMS_RANDOM.VALUE ( 1, 258347    )) product_key
       ,  ROUND ( DBMS_RANDOM.VALUE ( 1, 5000000   )) customer_key
       ,  to_date('20040520','yyyymmdd') + ROUND ( DBMS_RANDOM.VALUE ( 1, 3653 )) + 0 load_date
       ,  ROUND ( DBMS_RANDOM.VALUE ( 1, 15        )) product_quantity
    FROM  video_store.iterator
),
product_cost as
(
  SELECT bv.product_key
       ,  bv.customer_key
       ,  to_char(bv.load_date,'yyyymmdd') + 0 date_key
       ,  bv.load_date
       ,  bv.product_quantity
       ,  pd.product_price
       ,  ROUND ( pd.product_price * ROUND ( DBMS_RANDOM.VALUE ( .5, .9 ), 2 ), 2 ) product_cost
    FROM  base_values bv
            INNER JOIN video_store.product_dim pd ON bv.product_key = pd.product_key
),
SALE_TOTAL AS
(
  SELECT  pc.*
       ,  pc.product_quantity * pc.product_price sale_price
       ,  pc.product_quantity * pc.product_cost  sale_cost
    FROM  product_cost pc
)
SELECT  st.*
     ,  st.sale_price - st.sale_cost sale_net
  FROM  sale_total st;


@table_test_create





